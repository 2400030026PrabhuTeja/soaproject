package com.agritech.irrigation.controller;

import com.agritech.irrigation.dto.IrrigationRequest;
import com.agritech.irrigation.dto.IrrigationResponse;
import com.agritech.irrigation.service.IrrigationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/irrigation")
public class IrrigationController {

    private final IrrigationService service;

    public IrrigationController(IrrigationService service) {
        this.service = service;
    }

    @PostMapping("/start")
    public IrrigationResponse startIrrigation(@RequestBody IrrigationRequest request) {
        return service.startIrrigation(request);
    }

    @PostMapping("/stop/{farmId}")
    public IrrigationResponse stopIrrigation(@PathVariable String farmId) {
        return service.stopIrrigation(farmId);
    }

    @GetMapping("/status/{farmId}")
    public List<IrrigationResponse> getStatus(@PathVariable String farmId) {
        return service.getStatus(farmId);
    }

    @GetMapping
    public List<IrrigationResponse> getAllIrrigations() {
        return service.getAllIrrigations();
    }

    @ExceptionHandler(RuntimeException.class)
    public org.springframework.http.ResponseEntity<?> handleException(RuntimeException e) {
        return org.springframework.http.ResponseEntity
                .status(org.springframework.http.HttpStatus.BAD_REQUEST)
                .body(java.util.Map.of("error", e.getMessage()));
    }
}
