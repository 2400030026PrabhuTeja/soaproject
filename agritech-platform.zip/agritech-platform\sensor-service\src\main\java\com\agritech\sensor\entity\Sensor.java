﻿package com.agritech.sensor.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sensors")
public class Sensor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String sensorId;
    private String farmId;
    private String location;
    private Double soilMoisture;
    private Double soilTemperature;
    private LocalDateTime timestamp;

    public Sensor() {}

    public Sensor(Long id, String sensorId, String farmId, String location,
                  Double soilMoisture, Double soilTemperature, LocalDateTime timestamp) {
        this.id = id; this.sensorId = sensorId; this.farmId = farmId;
        this.location = location; this.soilMoisture = soilMoisture;
        this.soilTemperature = soilTemperature; this.timestamp = timestamp;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getSensorId() { return sensorId; }
    public void setSensorId(String sensorId) { this.sensorId = sensorId; }
    public String getFarmId() { return farmId; }
    public void setFarmId(String farmId) { this.farmId = farmId; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public Double getSoilMoisture() { return soilMoisture; }
    public void setSoilMoisture(Double soilMoisture) { this.soilMoisture = soilMoisture; }
    public Double getSoilTemperature() { return soilTemperature; }
    public void setSoilTemperature(Double soilTemperature) { this.soilTemperature = soilTemperature; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
