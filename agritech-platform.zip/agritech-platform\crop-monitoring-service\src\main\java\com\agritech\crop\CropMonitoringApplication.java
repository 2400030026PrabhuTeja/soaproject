﻿package com.agritech.crop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class CropMonitoringApplication {
    public static void main(String[] args) {
        SpringApplication.run(CropMonitoringApplication.class, args);
    }
}
