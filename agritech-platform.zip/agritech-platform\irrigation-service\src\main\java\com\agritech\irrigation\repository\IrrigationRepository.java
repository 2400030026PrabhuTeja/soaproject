﻿package com.agritech.irrigation.repository;

import com.agritech.irrigation.entity.Irrigation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface IrrigationRepository extends JpaRepository<Irrigation, Long> {
    List<Irrigation> findByFarmId(String farmId);
    List<Irrigation> findByStatus(String status);
}
