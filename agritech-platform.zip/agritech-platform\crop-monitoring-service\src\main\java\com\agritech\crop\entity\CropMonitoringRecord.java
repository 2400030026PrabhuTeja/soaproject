﻿package com.agritech.crop.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "crop_monitoring_records")
public class CropMonitoringRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String sensorId;
    private String farmId;
    private Double soilMoisture;
    private Double soilTemperature;
    private String cropHealth;
    private String recommendation;
    private LocalDateTime monitoredAt;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getSensorId() { return sensorId; }
    public void setSensorId(String sensorId) { this.sensorId = sensorId; }
    public String getFarmId() { return farmId; }
    public void setFarmId(String farmId) { this.farmId = farmId; }
    public Double getSoilMoisture() { return soilMoisture; }
    public void setSoilMoisture(Double soilMoisture) { this.soilMoisture = soilMoisture; }
    public Double getSoilTemperature() { return soilTemperature; }
    public void setSoilTemperature(Double soilTemperature) { this.soilTemperature = soilTemperature; }
    public String getCropHealth() { return cropHealth; }
    public void setCropHealth(String cropHealth) { this.cropHealth = cropHealth; }
    public String getRecommendation() { return recommendation; }
    public void setRecommendation(String recommendation) { this.recommendation = recommendation; }
    public LocalDateTime getMonitoredAt() { return monitoredAt; }
    public void setMonitoredAt(LocalDateTime monitoredAt) { this.monitoredAt = monitoredAt; }
}
