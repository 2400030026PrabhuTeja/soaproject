﻿package com.agritech.sensor.repository;

import com.agritech.sensor.entity.Sensor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SensorRepository extends JpaRepository<Sensor, Long> {
    Optional<Sensor> findBySensorId(String sensorId);
    List<Sensor> findByFarmId(String farmId);
}
