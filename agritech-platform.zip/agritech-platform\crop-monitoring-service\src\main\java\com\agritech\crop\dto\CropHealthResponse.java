﻿package com.agritech.crop.dto;

public class CropHealthResponse {
    private String sensorId;
    private String farmId;
    private Double soilMoisture;
    private Double soilTemperature;
    private String cropHealth;
    private String recommendation;
    private boolean irrigationStarted;
    public String getSensorId() { return sensorId; }
    public void setSensorId(String sensorId) { this.sensorId = sensorId; }
    public String getFarmId() { return farmId; }
    public void setFarmId(String farmId) { this.farmId = farmId; }
    public Double getSoilMoisture() { return soilMoisture; }
    public void setSoilMoisture(Double soilMoisture) { this.soilMoisture = soilMoisture; }
    public Double getSoilTemperature() { return soilTemperature; }
    public void setSoilTemperature(Double soilTemperature) { this.soilTemperature = soilTemperature; }
    public String getCropHealth() { return cropHealth; }
    public void setCropHealth(String cropHealth) { this.cropHealth = cropHealth; }
    public String getRecommendation() { return recommendation; }
    public void setRecommendation(String recommendation) { this.recommendation = recommendation; }
    public boolean isIrrigationStarted() { return irrigationStarted; }
    public void setIrrigationStarted(boolean irrigationStarted) { this.irrigationStarted = irrigationStarted; }
}
