﻿package com.agritech.sensor.dto;

public class SensorRequest {
    private String sensorId;
    private String farmId;
    private String location;
    private Double soilMoisture;
    private Double soilTemperature;
    public String getSensorId() { return sensorId; }
    public void setSensorId(String sensorId) { this.sensorId = sensorId; }
    public String getFarmId() { return farmId; }
    public void setFarmId(String farmId) { this.farmId = farmId; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public Double getSoilMoisture() { return soilMoisture; }
    public void setSoilMoisture(Double soilMoisture) { this.soilMoisture = soilMoisture; }
    public Double getSoilTemperature() { return soilTemperature; }
    public void setSoilTemperature(Double soilTemperature) { this.soilTemperature = soilTemperature; }
}
