package com.agritech.sensor.controller;

import com.agritech.sensor.dto.SensorRequest;
import com.agritech.sensor.dto.SensorResponse;
import com.agritech.sensor.service.SensorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sensors")
public class SensorController {

    private final SensorService sensorService;

    public SensorController(SensorService sensorService) {
        this.sensorService = sensorService;
    }

    @PostMapping
    public SensorResponse createSensor(@RequestBody SensorRequest request) {
        return sensorService.createSensor(request);
    }

    @GetMapping
    public List<SensorResponse> getAllSensors() {
        return sensorService.getAllSensors();
    }

    @GetMapping("/{id}")
    public SensorResponse getSensorById(@PathVariable Long id) {
        return sensorService.getSensorById(id);
    }

    @GetMapping("/by-sensor-id/{sensorId}")
    public SensorResponse getSensorBySensorId(@PathVariable String sensorId) {
        return sensorService.getSensorBySensorId(sensorId);
    }

    @ExceptionHandler(RuntimeException.class)
    public org.springframework.http.ResponseEntity<?> handleException(RuntimeException e) {
        return org.springframework.http.ResponseEntity
                .status(org.springframework.http.HttpStatus.NOT_FOUND)
                .body(java.util.Map.of("error", e.getMessage()));
    }
}
