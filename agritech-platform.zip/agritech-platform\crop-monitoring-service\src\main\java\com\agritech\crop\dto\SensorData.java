﻿package com.agritech.crop.dto;

import java.time.LocalDateTime;

public class SensorData {
    private Long id;
    private String sensorId;
    private String farmId;
    private String location;
    private Double soilMoisture;
    private Double soilTemperature;
    private LocalDateTime timestamp;
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getSensorId() { return sensorId; }
    public void setSensorId(String sensorId) { this.sensorId = sensorId; }
    public String getFarmId() { return farmId; }
    public void setFarmId(String farmId) { this.farmId = farmId; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public Double getSoilMoisture() { return soilMoisture; }
    public void setSoilMoisture(Double soilMoisture) { this.soilMoisture = soilMoisture; }
    public Double getSoilTemperature() { return soilTemperature; }
    public void setSoilTemperature(Double soilTemperature) { this.soilTemperature = soilTemperature; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
