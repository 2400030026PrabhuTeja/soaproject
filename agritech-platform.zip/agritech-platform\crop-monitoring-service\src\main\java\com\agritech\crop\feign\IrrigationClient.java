﻿package com.agritech.crop.feign;

import com.agritech.crop.dto.IrrigationRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "IRRIGATION-SERVICE")
public interface IrrigationClient {
    @PostMapping("/irrigation/start")
    Object startIrrigation(@RequestBody IrrigationRequest request);
}
