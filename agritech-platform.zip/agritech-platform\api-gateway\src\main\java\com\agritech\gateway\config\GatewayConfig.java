package com.agritech.gateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                // Direct routes
                .route("auth_direct_route", r -> r.path("/auth/**")
                        .uri("lb://AUTH-SERVICE"))
                .route("sensor_direct_route", r -> r.path("/sensors/**")
                        .uri("lb://SENSOR-SERVICE"))
                .route("crop_direct_route", r -> r.path("/crops/**")
                        .uri("lb://CROP-MONITORING-SERVICE"))
                .route("irrigation_direct_route", r -> r.path("/irrigation/**")
                        .uri("lb://IRRIGATION-SERVICE"))

                // Service-prefixed routes (e.g. /sensor-service/sensors -> SENSOR-SERVICE /sensors)
                .route("auth_service_route", r -> r.path("/auth-service/**")
                        .filters(f -> f.stripPrefix(1))
                        .uri("lb://AUTH-SERVICE"))
                .route("sensor_service_route", r -> r.path("/sensor-service/**")
                        .filters(f -> f.stripPrefix(1))
                        .uri("lb://SENSOR-SERVICE"))
                .route("crop_service_route", r -> r.path("/crop-monitoring-service/**")
                        .filters(f -> f.stripPrefix(1))
                        .uri("lb://CROP-MONITORING-SERVICE"))
                .route("irrigation_service_route", r -> r.path("/irrigation-service/**")
                        .filters(f -> f.stripPrefix(1))
                        .uri("lb://IRRIGATION-SERVICE"))
                .build();
    }
}

