﻿package com.agritech.irrigation.dto;

import java.time.LocalDateTime;

public class IrrigationResponse {
    private Long id;
    private String farmId;
    private String status;
    private Integer duration;
    private String reason;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    public IrrigationResponse() {}
    public IrrigationResponse(Long id, String farmId, String status, Integer duration,
                               String reason, LocalDateTime startTime, LocalDateTime endTime) {
        this.id=id; this.farmId=farmId; this.status=status; this.duration=duration;
        this.reason=reason; this.startTime=startTime; this.endTime=endTime;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getFarmId() { return farmId; }
    public void setFarmId(String farmId) { this.farmId = farmId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Integer getDuration() { return duration; }
    public void setDuration(Integer duration) { this.duration = duration; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
}
