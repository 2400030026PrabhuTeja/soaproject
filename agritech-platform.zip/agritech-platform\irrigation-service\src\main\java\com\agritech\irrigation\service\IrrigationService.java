﻿package com.agritech.irrigation.service;

import com.agritech.irrigation.dto.IrrigationRequest;
import com.agritech.irrigation.dto.IrrigationResponse;
import com.agritech.irrigation.entity.Irrigation;
import com.agritech.irrigation.repository.IrrigationRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class IrrigationService {

    private final IrrigationRepository repository;

    public IrrigationService(IrrigationRepository repository) {
        this.repository = repository;
    }

    public IrrigationResponse startIrrigation(IrrigationRequest request) {
        Optional<Irrigation> existing = repository.findByFarmId(request.getFarmId())
                .stream().filter(i -> "ACTIVE".equals(i.getStatus())).findFirst();
        if (existing.isPresent()) return mapToResponse(existing.get());

        Irrigation irrigation = new Irrigation();
        irrigation.setFarmId(request.getFarmId());
        irrigation.setDuration(request.getDuration() != null ? request.getDuration() : 15);
        irrigation.setReason(request.getReason());
        irrigation.setStatus("ACTIVE");
        irrigation.setStartTime(LocalDateTime.now());
        irrigation = repository.save(irrigation);
        return mapToResponse(irrigation);
    }

    public IrrigationResponse stopIrrigation(String farmId) {
        Optional<Irrigation> activeOpt = repository.findByFarmId(farmId)
                .stream().filter(i -> "ACTIVE".equals(i.getStatus())).findFirst();
        if (activeOpt.isPresent()) {
            Irrigation irrigation = activeOpt.get();
            irrigation.setStatus("STOPPED");
            irrigation.setEndTime(LocalDateTime.now());
            return mapToResponse(repository.save(irrigation));
        }
        throw new RuntimeException("No ACTIVE irrigation found for farmId: " + farmId);
    }

    public List<IrrigationResponse> getStatus(String farmId) {
        return repository.findByFarmId(farmId).stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    public List<IrrigationResponse> getAllIrrigations() {
        return repository.findAll().stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    private IrrigationResponse mapToResponse(Irrigation i) {
        return new IrrigationResponse(i.getId(), i.getFarmId(), i.getStatus(),
                i.getDuration(), i.getReason(), i.getStartTime(), i.getEndTime());
    }
}
