﻿package com.agritech.crop.repository;

import com.agritech.crop.entity.CropMonitoringRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CropMonitoringRepository extends JpaRepository<CropMonitoringRecord, Long> {
}
