﻿package com.agritech.irrigation.dto;

public class IrrigationRequest {
    private String farmId;
    private Integer duration;
    private String reason;
    public String getFarmId() { return farmId; }
    public void setFarmId(String farmId) { this.farmId = farmId; }
    public Integer getDuration() { return duration; }
    public void setDuration(Integer duration) { this.duration = duration; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
}
