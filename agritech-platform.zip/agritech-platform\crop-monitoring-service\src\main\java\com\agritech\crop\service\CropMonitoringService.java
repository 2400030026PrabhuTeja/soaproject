package com.agritech.crop.service;

import com.agritech.crop.dto.CropHealthResponse;
import com.agritech.crop.dto.IrrigationRequest;
import com.agritech.crop.dto.SensorData;
import com.agritech.crop.entity.CropMonitoringRecord;
import com.agritech.crop.feign.IrrigationClient;
import com.agritech.crop.feign.SensorClient;
import com.agritech.crop.repository.CropMonitoringRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CropMonitoringService {

    private final SensorClient sensorClient;
    private final IrrigationClient irrigationClient;
    private final CropMonitoringRepository repository;

    @Value("${app.moisture.critical.threshold:30.0}")
    private double criticalThreshold;

    @Value("${app.moisture.moderate.threshold:50.0}")
    private double moderateThreshold;

    @Value("${app.irrigation.duration:15}")
    private int irrigationDuration;

    public CropMonitoringService(SensorClient sensorClient, IrrigationClient irrigationClient,
                                  CropMonitoringRepository repository) {
        this.sensorClient = sensorClient;
        this.irrigationClient = irrigationClient;
        this.repository = repository;
    }

    public CropHealthResponse monitorCrop(String sensorId) {
        SensorData data = sensorClient.getSensorBySensorId(sensorId);

        String health;
        String recommendation;
        boolean irrigationStarted = false;

        if (data.getSoilMoisture() < criticalThreshold) {
            health = "NEEDS_IRRIGATION";
            recommendation = "Soil moisture critically low (" + data.getSoilMoisture() + "%). Start irrigation immediately.";
            try {
                irrigationClient.startIrrigation(
                        new IrrigationRequest(data.getFarmId(), irrigationDuration,
                                "Low soil moisture: " + data.getSoilMoisture() + "%"));
                irrigationStarted = true;
            } catch (Exception e) {
                recommendation += " (Automated trigger attempted. Note: " + e.getMessage() + ")";
            }
        } else if (data.getSoilMoisture() < moderateThreshold) {
            health = "MODERATE";
            recommendation = "Soil moisture is moderate (" + data.getSoilMoisture() + "%). Monitor closely.";
        } else {
            health = "HEALTHY";
            recommendation = "Crop is healthy. Soil moisture optimal (" + data.getSoilMoisture() + "%).";
        }

        CropMonitoringRecord record = new CropMonitoringRecord();
        record.setSensorId(data.getSensorId());
        record.setFarmId(data.getFarmId());
        record.setSoilMoisture(data.getSoilMoisture());
        record.setSoilTemperature(data.getSoilTemperature());
        record.setCropHealth(health);
        record.setRecommendation(recommendation);
        record.setMonitoredAt(LocalDateTime.now());
        repository.save(record);

        CropHealthResponse response = new CropHealthResponse();
        response.setSensorId(data.getSensorId());
        response.setFarmId(data.getFarmId());
        response.setSoilMoisture(data.getSoilMoisture());
        response.setSoilTemperature(data.getSoilTemperature());
        response.setCropHealth(health);
        response.setRecommendation(recommendation);
        response.setIrrigationStarted(irrigationStarted);
        return response;
    }

    public List<CropMonitoringRecord> getHistory() {
        return repository.findAll();
    }
}
