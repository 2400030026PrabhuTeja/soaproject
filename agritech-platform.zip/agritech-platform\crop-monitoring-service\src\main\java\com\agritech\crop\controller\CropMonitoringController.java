package com.agritech.crop.controller;

import com.agritech.crop.dto.CropHealthResponse;
import com.agritech.crop.entity.CropMonitoringRecord;
import com.agritech.crop.service.CropMonitoringService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/crops")
public class CropMonitoringController {

    private final CropMonitoringService service;

    public CropMonitoringController(CropMonitoringService service) {
        this.service = service;
    }

    @GetMapping("/monitor/{sensorId}")
    public CropHealthResponse monitorCrop(@PathVariable String sensorId) {
        return service.monitorCrop(sensorId);
    }

    @GetMapping("/history")
    public List<CropMonitoringRecord> getHistory() {
        return service.getHistory();
    }

    @ExceptionHandler(RuntimeException.class)
    public org.springframework.http.ResponseEntity<?> handleException(RuntimeException e) {
        return org.springframework.http.ResponseEntity
                .status(org.springframework.http.HttpStatus.BAD_REQUEST)
                .body(java.util.Map.of("error", e.getMessage()));
    }
}
