﻿package com.agritech.crop.feign;

import com.agritech.crop.dto.SensorData;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "SENSOR-SERVICE")
public interface SensorClient {
    @GetMapping("/sensors/by-sensor-id/{sensorId}")
    SensorData getSensorBySensorId(@PathVariable("sensorId") String sensorId);
}
