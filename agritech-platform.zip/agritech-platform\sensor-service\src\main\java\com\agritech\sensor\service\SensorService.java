﻿package com.agritech.sensor.service;

import com.agritech.sensor.dto.SensorRequest;
import com.agritech.sensor.dto.SensorResponse;
import com.agritech.sensor.entity.Sensor;
import com.agritech.sensor.repository.SensorRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SensorService {

    private final SensorRepository sensorRepository;

    public SensorService(SensorRepository sensorRepository) {
        this.sensorRepository = sensorRepository;
    }

    public SensorResponse createSensor(SensorRequest request) {
        Sensor sensor = new Sensor();
        sensor.setSensorId(request.getSensorId());
        sensor.setFarmId(request.getFarmId());
        sensor.setLocation(request.getLocation());
        sensor.setSoilMoisture(request.getSoilMoisture());
        sensor.setSoilTemperature(request.getSoilTemperature());
        sensor.setTimestamp(LocalDateTime.now());
        sensor = sensorRepository.save(sensor);
        return mapToResponse(sensor);
    }

    public List<SensorResponse> getAllSensors() {
        return sensorRepository.findAll().stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    public SensorResponse getSensorById(Long id) {
        Sensor sensor = sensorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sensor not found with id: " + id));
        return mapToResponse(sensor);
    }

    public SensorResponse getSensorBySensorId(String sensorId) {
        Sensor sensor = sensorRepository.findBySensorId(sensorId)
                .orElseThrow(() -> new RuntimeException("Sensor not found: " + sensorId));
        return mapToResponse(sensor);
    }

    private SensorResponse mapToResponse(Sensor sensor) {
        return new SensorResponse(sensor.getId(), sensor.getSensorId(), sensor.getFarmId(),
                sensor.getLocation(), sensor.getSoilMoisture(), sensor.getSoilTemperature(), sensor.getTimestamp());
    }
}
