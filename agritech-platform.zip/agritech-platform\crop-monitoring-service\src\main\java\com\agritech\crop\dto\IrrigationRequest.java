﻿package com.agritech.crop.dto;

public class IrrigationRequest {
    private String farmId;
    private Integer duration;
    private String reason;
    public IrrigationRequest() {}
    public IrrigationRequest(String farmId, Integer duration, String reason) {
        this.farmId = farmId; this.duration = duration; this.reason = reason;
    }
    public String getFarmId() { return farmId; }
    public void setFarmId(String farmId) { this.farmId = farmId; }
    public Integer getDuration() { return duration; }
    public void setDuration(Integer duration) { this.duration = duration; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
}
