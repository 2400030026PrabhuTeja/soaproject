﻿package com.agritech.irrigation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class IrrigationServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(IrrigationServiceApplication.class, args);
    }
}
