﻿package com.agritech.sensor;

import com.agritech.sensor.entity.Sensor;
import com.agritech.sensor.repository.SensorRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

import java.time.LocalDateTime;

@SpringBootApplication
@EnableDiscoveryClient
public class SensorServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(SensorServiceApplication.class, args);
    }

    @Bean
    public CommandLineRunner loadSampleData(SensorRepository repository) {
        return args -> {
            repository.save(new Sensor(null, "S001", "FARM001", "North Field", 22.5, 29.4, LocalDateTime.now()));
            repository.save(new Sensor(null, "S002", "FARM001", "South Field", 65.0, 25.1, LocalDateTime.now()));
            repository.save(new Sensor(null, "S003", "FARM002", "East Field",  18.0, 32.0, LocalDateTime.now()));
            repository.save(new Sensor(null, "S004", "FARM002", "West Field",  45.0, 27.8, LocalDateTime.now()));
        };
    }
}
